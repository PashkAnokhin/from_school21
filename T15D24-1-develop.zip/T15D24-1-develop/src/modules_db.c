/*
Создать программу src/modules_db.c, в которой разместить точку входа и меню управления (считывание базы, вывод
и т.д.).

Добавь в src/modules_db.c вызов функции, реализующей инструкцию из List 1.

Теперь, если он снова взбунтуется, достаточно
выключить все его включенные дополнительные модули (перевести их статус в 0),
удалить записи про них (простановкой соответствующего флага в 1),
а главный модуль (c id 0) перевести в защищенный режим (последовательным переводом в статус 0, затем 1, затем
- 20), и переместить его в первую ячейку первого уровня памяти с выставлением этому уровню флага
защищенности 1.


Добавить вывод, что в первой ячейке первого уровня находится только главный модуль ИИ, при помощи описанных
раннее функций. Для отладки добавить возможность просмотра содержимого всех таблиц, добавления и удаления
значений в них.
*/

#include <stdio.h>

#include "shared.h"

int main_menu();
int db_menu(int menu);
void clrscr(void);

int main() {
    int menu = 0;
    menu = main_menu();
    if (menu != 0) db_menu(menu);

    return 0;
}

int main_menu() {
    // int err = 1;
    int menu = 0;
    clrscr();
    printf("--------------\n");
    printf("  Main menu\n");
    printf("--------------\n\n");
    printf("select a database:\n");
    printf(" 1: levels\n");
    printf(" 2: modules\n");
    printf(" 3: status events\n");
    printf(" 4: all\n");
    printf(" 0: Exit\n");

    while (1) {
        if (scanf("%d", &menu) != 1 || menu < 0 || menu > 4)

        {
            printf("Exit: please, enter the corrent number\n");
        } else

            break;
    }

    return menu;
}

int db_menu(int menu) {
    int n = 0;
    int operation = 0;
    int err = 0;

    clrscr();
    printf("----------------\n");
    printf("Database menu\n");
    printf("----------------\n\n");
    switch (menu) {
        case 1:
            printf("Database LEVELS.\n");
            break;
        case 2:
            printf("Database MODULES.\n");
            break;
        case 3:
            printf("Database STATUS EVENTS.\n");
            break;
        case 4:
            printf("ALL databases\n");
            break;
    }
    printf("Choose the operation: \n");
    printf(" 1: SELECT * from \n");
    printf(" 0: Exit\n");
    printf("-------------------\n");

    if (scanf("%d", &operation) != 1 || operation < 0 || operation > 1) err = 1;
    if (!err) {
        if (operation != 0) switch (menu) {
                case 1:
                    printf("Enter number of rows to output: ");
                    if (scanf("%d", &n) != 1 || n < 0) {
                        printf("Incorret input, please enter a correct number of rows.\n");
                        menu = 1;
                    } else {
                        menu = 0;
                        clrscr();
                        select_from(1, n);
                    }
                    break;
                case 2:
                    printf("Enter number of rows to output: ");
                    if (scanf("%d", &n) != 1 || n < 0) {
                        printf("Incorret input, please enter a correct number of rows.\n");
                        menu = 1;
                    } else {
                        menu = 0;
                        clrscr();
                        select_from(2, n);
                    }
                    break;
                case 3:
                    printf("Enter number of rows to output: ");
                    if (scanf("%d", &n) != 1 || n < 0) {
                        printf("Incorret input, please enter a correct number of rows.\n");
                        menu = 1;
                    } else {
                        menu = 0;
                        clrscr();
                        select_from(3, n);
                    }
                    break;
                case 4:
                    printf("Enter number of rows to output: ");
                    if (scanf("%d", &n) != 1 || n < 0) {
                        printf("Incorret input, please enter a correct number of rows.\n");
                        menu = 1;
                    } else {
                        menu = 0;
                        clrscr();
                        printf("LEVELS:\n");
                        select_from(1, n);
                        printf("\nMODULES:\n");
                        select_from(2, n);
                        printf("\nSTATUS EVENTS:\n");
                        select_from(3, n);
                    }
                    break;
            }
    }
    if (err)
        return err;
    else
        return menu;
}

void clrscr(void) {
    // char a[80];
    printf("\033[2J");   /* Clear the entire screen. */
    printf("\033[0;0f"); /* Move cursor to the top left hand corner
                          */
}
