/*
Таблица событий изменения статуса («STATUS_EVENTS») состоит из:

Id события (int);
Id модуля (int);
Новый статус модуля (int);
Дата изменения статуса (char[10 + 1] вида «dd.mm.yyyy\0»);
Время изменения статуса (char[8 + 1] вида «hh:mm:ss\0»).
*/

#include <stdio.h>

#include "shared.h"

void status_events(int n) {
    struct status_events event;

    FILE *fp = fopen(EVENTS_PATH, "rb");

    while (fread(&event, sizeof(struct status_events), 1, fp) != 0 && n > 0) {
        printf("%d %d %d %s %s\n", event.event_id, event.module_id, event.module_status_new,
               event.modify_date, event.modify_time);
        n--;
    }
    if (n > 0) printf("end of file\n");

    fclose(fp);
}
