/*
Основная таблица модулей («MODULES») состоит из:

Id модуля (int);
Название модуля (char[30]);
Номер уровня памяти,  где находится модуль (int);
Номер ячейки, где находится модуль на данном уровне (int);
Флаг удаления (int).
*/

#include <stdio.h>

#include "shared.h"

void modules_print(int n) {
    struct modules module;

    FILE *fp = fopen(MODULES_PATH, "rb");

    while (fread(&module, sizeof(struct modules), 1, fp) != 0 && n > 0) {
        printf("%d %s %d %d %d\n", module.module_id, module.module_name, module.module_level,
               module.module_cell_num, module.flag);
        n--;
    }
    if (n > 0) printf("end of file\n");

    fclose(fp);
}