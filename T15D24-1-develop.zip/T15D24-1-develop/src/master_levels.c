/*
Таблица уровней («LEVELS») состоит из:

Номера уровня памяти (int);
Кол-ва ячеек на уровне (int);
Флаг защищенности (int).
*/

#include <stdio.h>

#include "shared.h"

void levels_print(int n) {
    struct levels level;

    FILE *fp = fopen(LEVELS_PATH, "rb");

    while (fread(&level, sizeof(struct levels), 1, fp) != 0 && n > 0) {
        printf("%d %d %d \n", level.level_or_memory, level.count_cells, level.flag);
        n--;
    }
    if (n > 0) printf("end of file\n");

    fclose(fp);
}