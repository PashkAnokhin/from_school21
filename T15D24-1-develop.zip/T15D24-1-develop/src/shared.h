#ifndef ENTITY_H
#define ENTITY_H

#define LEVELS_PATH "../materials/master_levels.db"
#define MODULES_PATH "../materials/master_modules.db"
#define EVENTS_PATH "../materials/master_status_events.db"

/*
//////////////////////////////////////////////////////
ENTITY *select(FILE *db, int id);
int delete(FILE *db, int id);
int insert(FILE *db, ENTITY *entity);
int update(FILE *db, int id, ENTITY *entity);
//////////////////////////////////////////////////////
*/

struct levels {
    int level_or_memory;
    int count_cells;
    int flag;
};

struct modules {
    int module_id;
    char module_name[30];
    int module_level;
    int module_cell_num;
    int flag;
};

struct status_events {
    int event_id;
    int module_id;
    int module_status_new;
    char modify_date[11];
    char modify_time[9];
};

void select_from(int base, int n);
void levels_print(int n);
void modules_print(int n);
void status_events(int n);

#endif
