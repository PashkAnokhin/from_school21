/*
Создать файл src/shared.c, в котором реализовать общие операции над таблицами БД
 (SELECT, INSERT, UPDATE и DELETE) и все необходимые агрегационные запросы
 (получить все включенные модули, получить все модули на первом уровне памяти и т.д.).

 Создать для каждой таблицы БД файл src/[db_name].c с конкретными реализациями функций
 по обработке отдельной таблицы рассматриваемой БД.
 */

#include "shared.h"

#include <stdio.h>

void select_from(int base, int n) {
    switch (base) {
        case 1:
            levels_print(n);
            break;
        case 2:
            modules_print(n);
            break;
        case 3:
            status_events(n);
            break;
            /*
            case 2: modules_print(n);
            break;
            case 3: status_events_print(n);
            break;
            */
    }
}