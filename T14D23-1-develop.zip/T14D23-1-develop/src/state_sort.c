/*Создать программу src/state_sort.c, которая сортирует записи в бинарном файле datasets/door_state_1
по возрастанию их даты и времени.
Сам файл состоит из массива структур с целочисленными полями:
год, месяц, день, час, минута, секунда, статус (0/1), код.
Программа должна принимать путь к файлу.
Также должно быть реализовано меню, где
 пункт 0 - вывод содержимого файла в консоль,
 пункт 1 - сортировка содержимого файла и вывод на экран,
 пункт 2 - добавление записи, сортировка и вывод на экран.
Выгружать сразу весь файл в память нельзя. Рассмотреть абстракцию, что бинарный файл - массив на диске.
Разработать для этой абстракции вспомогательные функции. Eсли входной файл оказался пустым, и после этого в
него не добавляются новые записи, или если возникла любая ошибка, выводить n/a. Сборка проекта должна
осуществляться при помощи Makefile. Имя стадии - state_sort. Имя исполняемого файла - Quest_1. Исполняемый
файл должен располагаться в корне репозитория в папке build.*/

#include <stdio.h>

struct door {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

void print_file(char *path);
void sort_file(char *path);
int write_file(char *path);
int input_err(struct door door);

int main() {
    int err = 0;
    int flag_menu = 0;
    struct door door;
    int is_empty = 0;
    char path[1000];
    scanf("%s", path);

    FILE *fp = fopen(path, "rb");
    if (fp == NULL) err = 1;
    if (!err) {
        if (fread(&door, sizeof(struct door), 1, fp) == 0) is_empty = 1;
        fclose(fp);
    }
    if (!err)
        if (scanf("%d", &flag_menu) != 1 || flag_menu > 2 || flag_menu < 0) err = 1;

    if (!err) switch (flag_menu) {
            case 0:
                if (!is_empty)
                    print_file(path);
                else
                    err = 1;
                break;
            case 1:
                if (!is_empty) {
                    sort_file(path);
                    print_file(path);
                } else
                    err = 1;
                break;
            case 2:
                err = write_file(path);
                if (!err) print_file(path);
                break;
        }
    fclose(fp);
    if (err) printf("n/a");
    return 0;
}

void print_file(char *path) {
    struct door door;

    FILE *fp = fopen(path, "rb");
    while (fread(&door, sizeof(struct door), 1, fp) != 0) {
        printf("%d %d %d %d %d %d %d %d\n", door.year, door.month, door.day, door.hour, door.minute,
               door.second, door.status, door.code);
    }
    fclose(fp);
}

void sort_file(char *path) {
    // struct door door_cur;
    struct door door;
    struct door door_next;
    FILE *fp = fopen(path, "r+b");
    int i = 0;
    int j = 0;

    while (fseek(fp, -i * sizeof(door), SEEK_END) != 0) {
        while (fseek(fp, (j + 1) * sizeof(door), SEEK_SET) != 0) {
            fread(&door_next, sizeof(struct door), 1, fp);
            fseek(fp, -2 * sizeof(door), SEEK_CUR);
            fread(&door, sizeof(struct door), 1, fp);

            if (door_next.month > door.month) {
                fwrite(&door_next, sizeof(struct door), 1, fp);
            }
            j++;
        }
        i++;
    }
    fclose(fp);
}

int write_file(char *path) {
    int err = 0;
    struct door door;
    if (scanf("%d %d %d %d %d %d %d %d ", &door.year, &door.month, &door.day, &door.hour, &door.minute,
              &door.second, &door.status, &door.code) != 8 ||
        input_err(door))
        err = 1;

    if (!err) {
        FILE *fp = fopen(path, "r+b");

        fwrite(&door, sizeof(struct door), 1, fp);

        print_file(path);
        fclose(fp);
    }

    return err;
}

int input_err(struct door door) {
    int err = 0;
    err += door.month < 0 || door.month > 12;
    err += door.day < 0 || door.day > 31;
    err += door.hour < 0 || door.hour > 24;
    err += door.minute < 0 || door.minute > 60;
    err += door.second < 0 || door.second > 60;
    err += door.status < 0 || door.status > 1;

    return err;
}
